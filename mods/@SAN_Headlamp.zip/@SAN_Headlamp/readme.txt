Headlamp Mod v1.3 by MrSanchez

This mod gives you two functioning headlamps as well as functional helmet mounted flashlights.
Works with ArmA 3 v1.68+

Features:
	- Two functioning headlamps
	- Functional helmet mounted flashlights (vanilla helmets)
	- Ability to change lamp colours
	- Ability to change lamp brightness
	- Configurable by modules
	- Multiplayer support (Tested on Dedicated servers)
	- CBA Keybinding support
	- CBA Settings support

	
Mod Dependencies: 
	- None

Controls:
	- Toggle light on/off: SHIFT+N
	- Cycle Brightness: CTRL+N
	- Cycle Colors:  ALT+N

Known Issues:
	- Light does not follow the head during ambient animations (engine issue)
	- Update rate of light appears somewhat jagged in moving cars in MP (new script command needed)
	

Whitelisting:	
For (dedicated) server owners that run servers with CfgRemoteExec whitelisting enabled, 
whitelist the following functions:
- SAN_fnc_ToggleHeadlamp
- SAN_fnc_sendJIPinfo


Scripting:
To toggle the headlamp by script, use: _unit call SAN_fnc_ToggleHeadlamp_local; It takes a local argument _unit and has a global effect.

	
Credits:
loki.87 for the 'Headlamp Bravo' model & textures
Phantom Incorporated for intensive testing & motivation


Disclaimer:
This work is licensed under the Arma Public License Share Alike (APL-SA)
https://www.bistudio.com/community/licenses/arma-public-license-share-alike

This is the first release, let me know about any bugs/glitches.

Have fun.

Kind regards,
Sanchez