name = "MrSanchez' Headlamp Mod v1.3";
actionName = "PCI Website";
action = "http://www.phantom-incorporated.eu";
picture = "mod.paa";
overview = "Brighten your day!";