________________________________________ 


Enhanced Movement - BETA 

________________________________________ 

DONATE: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CPBSUGX4M6Q8S 
________________________________________ 


TO LEARN HOW TO BIND YOUR KEYS WATCH THE SECOND VIDEO ABOVE OR USE THIS LINK:
https://youtu.be/A64rrTyb-mY

________________________________________

DISCLAIMERS 

- use this at your own risk (obviously...) 

- this update will not fix (potentially break) old broken savegames 

________________________________________ 
MIRRORS 

armaholic: 

http://www.armaholic.com/page.php?id=27224 

BI forums: 

http://forums.bistudio.com/showthread.php?184977-Arma-Enhanced-Movement 

________________________________________ 
FEATURES 

- one context sensitive key to: 
--> jump 
--> climb on/over and step onto obstacles 

- one context sensitive key to: 
--> open doors/hatches and perform any close by actions 
--> climb ladders 
--> access the gear of any object (vehicles, ammoboxes, etc.) 
--> get quickly into prioritized vehicle seats
--> vehicle seat menu 

________________________________________ 
INSTRUCTIONS 

after installing the addon simply go ingame and press ESC. there will be a small menu that will allow you to bind your keys and adjust your settings. for a short demonstration see the video above. 

________________________________________ 
KNOWN ISSUES (please read this before reporting things) 

- some objects make you float (this has to be fixed by BI insdie the models) 

- some windows or general places are not climbable (again..this has to be fixed by BI inside the models) 

- clipping resulting in floating/clipping and generally unpleasing visuals 

________________________________________ 
FUTURE PLANS 

- improved animations 

________________________________________ 
CREDITS 

- various people i learned from over the years especially Einherj. the rest. you know who you are. thx! 
- thx Columdrum for the action code example 
- Apache7 for helping me sort some binarize problems and general rtm things 
- Macser for his awesome Blender rig that inspired me to make my own in max (coming soon) 
- Mikero for his great tools that simply work and do the job properly 
- LordPrimate for temporary signature solution
- BI for this amazing and weird ass game series that i hate and love at the same time 
- dedmen for optimisations tips

all beta testers and especially... 

Apache (indepth MP testing) 
Einherj (indepth MP testing) 
Deuce (indepth SP testing) 
Corporal_Lib (indepth SP testing) 
SerJames (indepth mod compatibility testing) 

________________________________________ 
LICENSE 

modification of the contents of this addon requires the author's (that would be me) permission.

the contents of this addon are not allowed for any type of commercial use. that includes derivatives of it. 

that includes using this as part of game modes/servers that have donation systems that are tied to ingame content as reward for donations, even if that content is not this addon specifically. this means the use of this is only allowed in a 100% free context. that obviously excludes normal servers that accept donations without ingame content perks. 

the use of contents of this addon (if permission was granted) is not allowed outside of arma games. that includes "very similar military simulators based on the RV engine".