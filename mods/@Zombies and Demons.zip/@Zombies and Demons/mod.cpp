name = "Ryan's Zombies & Demons";
picture = "mod.paa";