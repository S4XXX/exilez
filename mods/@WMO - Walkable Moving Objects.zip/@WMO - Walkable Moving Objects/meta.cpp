protocol = 1;
publishedid = 925018569;
name = "WMO - Walkable Moving Objects";
timestamp = 5247995920099529188;
